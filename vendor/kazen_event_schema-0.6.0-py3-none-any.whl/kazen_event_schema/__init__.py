"""kazen_event_schema — canonical KazenEvent schema shared across all KazenAI services.

Usage:
    from kazen_event_schema import KazenEvent, EventType, validate_kazen_event, is_known_event_type

No orchestrator-specific imports. Safe to install in any service.
"""

from __future__ import annotations

import re
import time
import uuid
from typing import Any, Dict, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

__version__ = "0.6.0"
__all__ = [
    "KazenEvent",
    "EventType",
    "KNOWN_EVENT_TYPES",
    "validate_kazen_event",
    "is_known_event_type",
    "normalize_event_type",
    "is_model_call",
    "ValidationError",
    # Typed payload classes
    "ModelCallPayload",
    "ToolCallPayload",
    "ToolRepairPayload",
    "ContextCompactionPayload",
    "GateDecisionPayload",
    "RunLifecyclePayload",
    "FinOpsPayload",
    "FinOpsBudgetPayload",
    "validate_payload",
    "MemoryWritePayload",
    "validate_memory_write_payload",
]

from .memory_write import MemoryWritePayload, validate_memory_write_payload  # noqa: E402

from .normalize import is_model_call, normalize_event_type  # noqa: E402

# ---------------------------------------------------------------------------
# Canonical event_type registry (dotted lowercase).
# ---------------------------------------------------------------------------
KNOWN_EVENT_TYPES: frozenset[str] = frozenset({
    "backlog.item_completed",
    "campaign.published",
    "checkpoint.saved",
    "code.approved",
    "context_pack.composed",
    "delivery.pr.created",
    "diagnostics.snapshot",
    "edits.applied",
    "event.unknown",
    "ci.failed",
    "ci.repaired",
    "drift.detected",
    "finops.budget.denied",
    "finops.budget.reserve",
    "finops.circuit_breaker.opened",
    "finops.stream_cutoff",
    "finops.pause",
    "finops.resumed",
    "anomaly.detected",
    "fsm.transition",
    "evidence.bundle.written",
    "gate.fast_path_bypass",
    "gate.decision",
    "gate.override.approved",
    "gate.override.requested",
    "finance.review_completed",
    "operating.review_completed",
    "playbook.suggested",
    "playbook.outcome_observed",
    "playbook.version_changed",
    "gatekeeper.complete",
    "gatekeeper.fallback_used",
    "growthops.approval.queued",
    "growthops.budget.exceeded",
    "growthops.ingest.completed",
    "growthops.run.completed",
    "growthops.run.failed",
    "growthops.run.started",
    # Company goal / OKR events (Month 10 — Self-Directing Intelligence)
    "goals.created",
    "goals.task.dispatched",
    "workforce.task.dispatched",
    "goals.task.completed",
    "goals.task.failed",
    "goals.completed",
    "human_gate",
    "kpi.snapshot",
    "learning.background_review_complete",
    "learning.snapshot",
    "brain.guard",
    "brain.retrieve",
    "context.compressed",
    "context.tool_result_compacted",
    "run.evidence_incomplete",
    "run.failed",
    "run.step.checkpointed",
    "session.indexed",
    "llm.call",  # deprecated alias; prefer model.call (normalized at ingest)
    "mcp.call",
    "memory.write",
    "meltdown.onset",
    "model.call",
    "permission_denied",
    "patch.applied",
    "plan.written",
    "pr.created",
    "replay.completed",
    "replay.started",
    "router.circuit_breaker_open",
    "routing.model_selected",
    "routing.profile_selected",
    "run.cancelled",
    "run.finished",
    "run.started",
    "sandbox.command",
    "sales.account_researched",
    "sales.approval_granted",
    "sales.approval_rejected",
    "sales.approval_requested",
    "sales.contact_selected",
    "sales.message_drafted",
    "sales.opportunity_stage_changed",
    "sales.opportunity_stalled",
    "sales.outbound_sent",
    "sales.outbound_staged",
    "sales.reply_received",
    "test.completed",
    "test.selected",
    "tool.call",
    "tool.pre_call",
    "tool.repair.applied",
    "support.case_resolved",
    "support.escalated",
    "user.gate_approved",
    "user.gate_rejected",
    "user.hunk_accepted",
    "user.hunk_rejected",
    "user.run_resumed",
    "user.run_started",
    "user.scope_expansion_requested",
    "verify.completed",
    "verification.evidence",
    "usage.recorded",
    "worktree.created",
    "worktree.isolation_unavailable",
})

# Convenient alias for IDE completions
EventType = str

_EVENT_TYPE_PATTERN = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$")


# ---------------------------------------------------------------------------
# Typed payload classes — one per event_type family.
# extra="allow" so producers can add new fields without breakage; the top-level
# KazenEvent uses extra="forbid" for strict wire compatibility.
# ---------------------------------------------------------------------------

class ModelCallPayload(BaseModel):
    model_config = ConfigDict(extra="allow", protected_namespaces=())
    model: str = ""
    routing_profile: Optional[str] = None
    model_tier: Optional[str] = None
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    cache_hit_ratio: Optional[float] = None
    prompt_hash: Optional[str] = None
    response_hash: Optional[str] = None


class ToolRepairPayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    scavenged: int = 0
    truncations_fixed: int = 0
    storms_broken: int = 0
    notes_redacted: Optional[str] = None


class ContextCompactionPayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    results_shrunk: int = 0
    tokens_saved_est: int = 0
    turn_index: Optional[int] = None
    middle_turns_summarised: Optional[int] = None


class ToolCallPayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    tool_name: str = ""
    args_hash: Optional[str] = None
    result_hash: Optional[str] = None


class GateDecisionPayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    gate_type: Optional[str] = None           # gate_0 | gate_1 | gate_2
    decision: Optional[str] = None            # approve | deny | escalate
    reason: Optional[str] = None
    brain_trace_node_id: Optional[str] = None


class RunLifecyclePayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    task_summary: Optional[str] = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None


class FinOpsPayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    threshold_usd: Optional[float] = None
    current_usd: Optional[float] = None
    reason: Optional[str] = None


class FinOpsBudgetPayload(BaseModel):
    """Pre-call FinOps reserve / deny events emitted by kazenai.spine."""

    model_config = ConfigDict(extra="allow", protected_namespaces=())
    allowed: bool = True
    reason: Optional[str] = None
    reserved_cost_usd: Optional[float] = None
    projected_cost_usd: Optional[float] = None
    actual_cost_usd: Optional[float] = None
    model: str = ""
    feature: str = ""


class UsagePayload(BaseModel):
    model_config = ConfigDict(extra="allow")
    module: str
    meter: str
    quantity: int = 1
    cost_cents: int = 0
    source_service: Optional[str] = None


# Maps event_type → payload validator class.
# Only event types with structured payloads are registered; others are allowed
# to carry arbitrary dicts (no validator registered = no validation performed).
_PAYLOAD_VALIDATORS: Dict[str, type[BaseModel]] = {
    "model.call": ModelCallPayload,
    "llm.call": ModelCallPayload,
    "tool.call": ToolCallPayload,
    "mcp.call": ToolCallPayload,
    "gate.decision": GateDecisionPayload,
    "gate.override.requested": GateDecisionPayload,
    "run.started": RunLifecyclePayload,
    "run.finished": RunLifecyclePayload,
    "run.failed": RunLifecyclePayload,
    "finops.budget.denied": FinOpsBudgetPayload,
    "finops.budget.reserve": FinOpsBudgetPayload,
    "finops.circuit_breaker.opened": FinOpsPayload,
    "finops.stream_cutoff": FinOpsPayload,
    "finops.pause": FinOpsPayload,
    "anomaly.detected": FinOpsPayload,
    "finops.trajectory": FinOpsPayload,
    "usage.recorded": UsagePayload,
    "tool.repair.applied": ToolRepairPayload,
    "context.tool_result_compacted": ContextCompactionPayload,
    "context.compressed": ContextCompactionPayload,
}


def validate_payload(event_type: str, payload: Dict[str, Any]) -> None:
    """Validate payload contents against the typed spec for this event_type.

    Raises:
        pydantic.ValidationError: if payload fields don't match the typed spec.
        Unknown event types pass through without validation.
    """
    validator_cls = _PAYLOAD_VALIDATORS.get(event_type)
    if validator_cls is not None:
        validator_cls.model_validate(payload)


class KazenEvent(BaseModel):
    """Strict KazenEvent schema v0.3.0 — used across all KazenAI services."""

    model_config = ConfigDict(extra="forbid")

    schema_version: str = "1.2"
    ts_ms: int = Field(default_factory=lambda: int(time.time() * 1000))
    timestamp_ms: Optional[int] = None
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()), min_length=8)
    org_id: str = "local"
    workspace_id: str = "default"
    project_id: str = "general"
    surface: str = "kazenai-agent-builder"
    client_id: Optional[str] = None  # cursor | claude_code | vscode | mcp
    agent_id: str = "devagent"
    agent_role: Optional[str] = None
    run_id: Optional[str] = None
    step_id: Optional[str] = None
    parent_step_id: Optional[str] = None
    parent_run_id: Optional[str] = None
    event_type: str
    tokens: Optional[int] = None
    tokens_used: Optional[int] = None
    cost_usd: Optional[float] = None
    latency_ms: Optional[int] = None
    gate_decision: Optional[str] = None
    gate_latency_s: Optional[float] = None
    difficulty_score: Optional[float] = None
    artifact_refs: Dict[str, Any] = Field(default_factory=dict)
    stage_budget_usd: Optional[float] = None
    remaining_budget_usd: Optional[float] = None
    projected_total_cost_usd: Optional[float] = None
    avoided_cost_usd: Optional[float] = None
    expected_success_probability: Optional[float] = None
    cost_quality_score: Optional[float] = None
    replay_group_id: Optional[str] = None
    frozen_trace_ref: Optional[str] = None
    drift_baseline_id: Optional[str] = None
    sandbox_backend: Optional[str] = None
    touched_node_ids: list[str] = Field(default_factory=list)
    retrieval_trace_id: Optional[str] = None
    code_graph_snapshot_id: Optional[str] = None
    verification_result: Dict[str, Any] = Field(default_factory=dict)
    payload: Dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _sync_compat_fields(self) -> "KazenEvent":
        if self.timestamp_ms is None:
            self.timestamp_ms = self.ts_ms
        if self.tokens_used is None and self.tokens is not None:
            self.tokens_used = self.tokens
        if self.tokens is None and self.tokens_used is not None:
            self.tokens = self.tokens_used
        return self

    @field_validator("event_type")
    @classmethod
    def _event_type_must_be_dotted_lowercase(cls, v: str) -> str:
        if not _EVENT_TYPE_PATTERN.fullmatch(v):
            raise ValueError(
                f"event_type '{v}' must be dotted lowercase identifiers "
                f"(e.g. 'model.call', 'run.started')"
            )
        return v


def validate_kazen_event(
    rec: Dict[str, Any],
    *,
    strict: bool = False,
    validate_payload_contents: bool = False,
) -> KazenEvent:
    """Parse and validate a dict as a KazenEvent.

    Args:
        rec: Raw dict (e.g. from JSON body).
        strict: If True, also reject unknown event_type values not in KNOWN_EVENT_TYPES.
        validate_payload_contents: If True, also validate the payload dict against the
            typed spec for the event_type (raises ValidationError on mismatch).

    Raises:
        pydantic.ValidationError: if the record is invalid.
    """
    ev = KazenEvent.model_validate(rec)
    if strict and ev.event_type not in KNOWN_EVENT_TYPES:
        raise ValueError(
            f"event_type '{ev.event_type}' is not in the KNOWN_EVENT_TYPES registry. "
            f"Register it or set strict=False to allow unknown types."
        )
    if validate_payload_contents and ev.payload:
        validate_payload(ev.event_type, ev.payload)
    return ev


def is_known_event_type(event_type: str) -> bool:
    """Return True if event_type is in the canonical registry."""
    return event_type in KNOWN_EVENT_TYPES
